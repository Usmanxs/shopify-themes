<div class="adv-wrapper">
	<?php echo houzez_option('adsense_space_3');?>
</div>